﻿using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Net;

namespace DownSide.SelfUpdater
{
    class UpdateVariables
    {
        public bool PatcherIsDownloading { get; set; }

        public bool UpdateCompleted { get; set; }

        public uint PatcherVersion { get; set; }

        public string PatcherExecutable { get; set; }

        public string PatcherArguments { get; set; }

        public string PatcherWebPath { get; set; }

        public WebClient WebClient { get; set; }

        public Stopwatch Stopwatch { get; set; }

        public DirectoryInfo PatcherFolder { get; set; }

        public DirectoryInfo TempFolder { get; set; }

        public KeyValueConfigurationCollection PatcherSettings { get; set; }

        public Configuration PatcherConfigFile { get; set; }

        public KeyValueConfigurationCollection SettingsPatcher { get; set; }

        public Configuration ConfigFilePatcher { get; set; }
    }
}
