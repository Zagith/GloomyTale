﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Forms;

namespace DownSide.Launcher
{
    public partial class SocialForm : Form
    {
        Form LauncherForm;
        public SocialForm(Form launcher)
        {
            LauncherForm = launcher;
            LauncherForm.Enabled = false;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LauncherForm.Enabled = true; ;
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("https://discord.gg/U28fTSW");

            }
            catch (Win32Exception noBrowser)
            {
                if (noBrowser.ErrorCode == -2147467259)
                    MessageBox.Show(noBrowser.Message);
            }
            catch (Exception other)
            {
                MessageBox.Show(other.Message);
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("https://www.youtube.com/channel/UCdjZWns7inchysipgP1i5wQ");

            }
            catch (Win32Exception noBrowser)
            {
                if (noBrowser.ErrorCode == -2147467259)
                    MessageBox.Show(noBrowser.Message);
            }
            catch (Exception other)
            {
                MessageBox.Show(other.Message);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {            
            try
            {
                Process.Start("https://www.instagram.com/downsidenos_official/");

            }
            catch (Win32Exception noBrowser)
            {
                if (noBrowser.ErrorCode == -2147467259)
                    MessageBox.Show(noBrowser.Message);
            }
            catch (Exception other)
            {
                MessageBox.Show(other.Message);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("http://downsidenos-revolution.gearhostpreview.com//");

            }
            catch (Win32Exception noBrowser)
            {
                if (noBrowser.ErrorCode == -2147467259)
                    MessageBox.Show(noBrowser.Message);
            }
            catch (Exception other)
            {
                MessageBox.Show(other.Message);
            }
        }
    }
}
