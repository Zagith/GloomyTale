﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DownSide.Launcher
{
    public partial class Settings : Form
    {
        Form launcherForm;
        uint PatchVersion;
        KeyValueConfigurationCollection DownsideSettings;
        Configuration DownsideConfigFile;
        public Settings(Form launcher, uint patchVersion, KeyValueConfigurationCollection downsideSettings, Configuration downsideConfigFile)
        {
            launcherForm = launcher;
            launcherForm.Enabled = false;
            PatchVersion = 0;
            DownsideSettings = downsideSettings;
            DownsideConfigFile = downsideConfigFile;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            launcherForm.Enabled = true; ;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Write2ConfigFile("patchVersion", PatchVersion.ToString());
            Thread.Sleep(2000);
            Application.Restart();
        }

        private void Write2ConfigFile(string key, string value)
        {
            try
            {
                DownsideSettings.Remove(key);
                DownsideSettings.Add(key, value);
                DownsideConfigFile.Save(ConfigurationSaveMode.Modified);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message + "\n\n" + e.StackTrace, "Write2ConfigFile Error");
                Environment.Exit(0);
            }
        }
    }
}
