﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DownSide.Launcher
{
    static class Program
    {
        private static bool enableNotice = true;
        private static string windowTitle = "Downside Patcher";
        private static string appExecutable = "NostaleClientX.exe";
        private static string appArguments = "";

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Thread.Sleep(1000);
            if (Process.GetProcessesByName(Path.GetFileNameWithoutExtension(Assembly.GetEntryAssembly().Location)).Count() > 1)
            {
                MessageBox.Show("Already Running");
                return;
            }

            //Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(true);
            Application.Run(new FormPatcher(enableNotice, windowTitle, appExecutable, appArguments));
        }
    }
}
