﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Net;

namespace DownSide.Launcher
{
    class Data
    {
        public bool EnableNotice { get; set; }
        public bool PatcherIsDownloading { get; set; }
        public bool UpdateCompleted { get; set; }
        public bool HasUpdates { get; set; }
        public uint PatchVersion { get; set; }
        public uint DownsideVersion { get; set; }
        public string AppFileName { get; set; }
        public string AppArguments { get; set; }
        public string NoticeText { get; set; }
        public string WindowTitle { get; set; }
        public Uri PatchesWebPath { get; set; }
        public WebClient WebClient { get; set; }
        public Package PackageOnDownloading { get; set; }
        public DirectoryInfo DownsideFolder { get; set; }
        public DirectoryInfo TempFolder { get; set; }
        public Stopwatch Stopwatch { get; set; }
        public KeyValueConfigurationCollection DownsideSettings { get; set; }
        public Configuration DownsideConfigFile { get; set; }
    }
}
